//
// CAF TestAgent Readme file
// Copyright (c) Symbian Software Ltd 2006. All rights reserved.
//

TestAgent
---------

This is a simple agent is used for testing the CAF framework. All agent functionality is contained within the client-side DLL, and there is no server executable.